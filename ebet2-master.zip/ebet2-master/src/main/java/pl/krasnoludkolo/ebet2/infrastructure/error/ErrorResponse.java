package pl.krasnoludkolo.ebet2.infrastructure.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
class ErrorResponse {

    private String message;

}
