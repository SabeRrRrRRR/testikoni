package pl.krasnoludkolo.ebet2.external.api;

public class MissingConfigurationException extends RuntimeException {

    MissingConfigurationException(String message) {
        super(message);
    }

}
