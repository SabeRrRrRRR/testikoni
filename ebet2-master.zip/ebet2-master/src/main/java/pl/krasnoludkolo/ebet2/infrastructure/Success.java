package pl.krasnoludkolo.ebet2.infrastructure;

public final class Success {

    public Success() {
    }

    public Success(Object o) {
    }

}
